'use strict';
// CHAOS v0.36.4o — continuous, physics-informed escape contest.
// Doesn't teleport characters, award an animation, or roll a dice.
// GRIP is not introduced as a redundant new rating: TAK/AWR express hold technique.
const ChaosTackleEscape=(()=>{
 const clamp=(v,a,b)=>Math.max(a,Math.min(b,Number.isFinite(v)?v:a));
 function drive(runner,defender,link){
  const forwardX=Math.cos(runner.face||0),forwardY=Math.sin(runner.face||0);
  const forwardSpeed=Math.max(0,(runner.vx||0)*forwardX+(runner.vy||0)*forwardY);
  const stamina=clamp(runner.stam??1,0,1),balance=clamp(runner.balance??1,0,1);
  // Existing TRK, STR, ACC and mass have different roles: contact resistance,
  // lower-body force, ability to reaccelerate feet, and inertia respectively.
  const legPower=clamp(((runner.STR||55)*.51+(runner.TRK||55)*.31+(runner.ACC||55)*.18-44)/55,0,1);
  const traction=clamp(.20+.80*balance,0,1)*clamp(.30+.70*stamina,0,1);
  // Successive physically demanding releases tax the planted legs. The load
  // decays with recovery, rather than an artificial "can't break 3 tackles" rule.
  const exertion=clamp(runner.breakExertion||0,0,1);
  const effort=clamp(legPower*traction*(.55+.45*clamp(forwardSpeed/5,0,1))*(1-.36*exertion),0,1);
  const grip=clamp(link.grip||0,0,1.6),quality=clamp(link.quality??.65,0,1.25);
  const secure=link.style==='wrap'&&grip>=.78&&quality>=.76;
  const hold=clamp((defender.TAK||65)*.50+(defender.STR||65)*.30+(defender.AWR||65)*.20,0,99);
  const defenderLeverage=clamp((.34+.66*quality)*(.40+.60*grip/1.3),0,1.5);
  // A controlled wrap is not defeated by the same force as a hand swipe.
  const difficulty=secure?1.48:link.style==='wrap'?1.12:link.style==='dive'?.94:.78;
  const opposing=clamp((hold/100)*defenderLeverage*difficulty,0,1.7);
  const runnerPower=effort*(.64+.36*clamp((runner.w||210)/230,.60,1.5));
  // Side pulls and momentum can destabilize a grip, but a purely trailing
  // defender shouldn't gain the same mechanical advantage as a square wrap.
  const dx=(runner.x||0)-(defender.x||0),dy=(runner.y||0)-(defender.y||0),len=Math.max(.001,Math.hypot(dx,dy));
  const separation=Math.max(0,((runner.vx||0)-(defender.vx||0))*dx/len+((runner.vy||0)-(defender.vy||0))*dy/len);
  const tensile=clamp(separation/8,0,.45);
  const margin=runnerPower+tensile*.25-opposing;
  return {effort,traction,legPower,runnerPower,opposing,margin,secure,forwardSpeed};
 }
 function step(runner,defender,link,dt){
  const contest=drive(runner,defender,link);
  const age=link.age||0;
  // No grip: not a break-tackle event at all.
  if((link.grip||0)<.24)return {...contest,broken:false,progress:0,kind:'none'};
  const lightHold=(link.grip||0)<.75 || link.style!=='wrap';
  const threshold=lightHold?.19:.62;
  const gain=Math.max(0,contest.margin-(lightHold?-.10:.09));
  const recovery=Math.max(0,-contest.margin)*.50;
  link.escapeProgress=clamp((link.escapeProgress||0)+dt*(gain*2.0-recovery*.85),0,1.5);
  // Physical contest accumulates over time. No one-frame stat-triggered escape.
  const broken=age>.15&&link.escapeProgress>=threshold;
  return {...contest,broken,progress:link.escapeProgress,kind:lightHold?'break tackle':'wrap break'};
 }
 return Object.freeze({drive,step});
})();
